﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;


/// <summary>
/// Summary description for User
/// </summary>
public class User
{
    private Database db;
    public User(Database db)
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string RegisterUser(string userName, string userEmail, string userPass)
    {
        try
        {
            EmailAddressAttribute foo = new EmailAddressAttribute();
            if (foo.IsValid(userEmail))
            {

                string query1 = "SELECT coupleID, coupleEmail FROM BridalCouple WHERE coupleEmail=@0";
                dynamic result = db.Query(query1, userEmail.ToLower());
                if (result.Count == 0)
                {

                    string query2 = "INSERT INTO BridalCouple (coupleUUID, coupleUsername, coupleEmail, coupleUserpassword, coupleUkey) VALUES (@0, @1, @2, @3, @4)";
                    db.Execute(query2, StringToGUID(userEmail).ToString(), userName, userEmail.ToLower(), BCrypt.Net.BCrypt.HashPassword(userPass), StringToGUID(userName).ToString());
                    result = db.Query(query1, userEmail.ToLower());
                    if (result.Count == 1)
                    {
                        string query3 = "INSERT INTO WishList (coupleID) VALUES (@0)";
                        db.Execute(query3, result[0]["coupleID"]);
                    }
                    return "Success!";
                }
                else
                {
                    return "E-mailadres is is ongeldig of bestaat al in onze database!";
                }
            }
            else
            {
                return "E-mailadres is is ongeldig of bestaat al in onze database!";
            }
        }
        catch (Exception e)
        {

            return e.ToString();
        }
    }
    public string LogIn(string email, string pass)
    {
        EmailAddressAttribute foo = new EmailAddressAttribute();
        if (foo.IsValid(email))
        {
            string query1 = "SELECT coupleEmail FROM BridalCouple WHERE coupleEmail=@0";
            dynamic result1 = db.Query(query1, email.ToLower());
            if (result1.Count == 1)
            {
                string query2 = "SELECT coupleUUID, coupleUserpassword FROM BridalCouple WHERE coupleEmail=@0";
                dynamic result2 = db.Query(query2, email);
                if (BCrypt.Net.BCrypt.Verify(pass, result2[0]["coupleUserpassword"]))
                {
                    string sessid = HttpContext.Current.Session.SessionID;
                    string uuid = result2[0]["coupleUUID"];
                    HttpContext.Current.Session["userUUID"] = uuid;
                    string query3 = "UPDATE BridalCouple SET coupleSessionPass=@0 WHERE coupleEmail=@1";
                    dynamic result3 = db.Execute(query3, HttpContext.Current.Session.SessionID, email);
                    return "Succesvol!";
                }
                else
                {
                    return "E-mail/wachtwoord incorrect!";
                }



            }
            else
            {
                return "E-mail/wachtwoord incorrect!";
            }

        }
        else
        {
            return "Email is ongeldig!";
        }
    }
    private Guid StringToGUID(string value)
    {
        // Create a new instance of the MD5CryptoServiceProvider object.
        MD5 md5Hasher = MD5.Create();
        // Convert the input string to a byte array and compute the hash.
        byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(value));
        return new Guid(data);
    }
    public bool IsLoggedIn()
    {
        if (HttpContext.Current.Session["userUUID"] != null)
        {
            if (HttpContext.Current.Session.SessionID != null)
            {
                string query = "SELECT coupleUUID FROM BridalCouple WHERE coupleUUID=@0 AND coupleSessionPass=@1";
                var result = db.Query(query, HttpContext.Current.Session["userUUID"], HttpContext.Current.Session.SessionID);
                if (result.Count() == 1)
                {
                    HttpContext.Current.Session["userUUID"] = HttpContext.Current.Session["userUUID"];
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
        return false;

    }
    public dynamic getUser()
    {
        if (HttpContext.Current.Session["userUUID"] != null)
        {
            if (HttpContext.Current.Session.SessionID != null)
            {
                string query = "SELECT coupleUUID, coupleUsername, coupleEmail, coupleUKey  FROM BridalCouple WHERE coupleUUID=@0 AND coupleSessionPass=@1";

                dynamic result = db.Query(query, HttpContext.Current.Session["userUUID"], HttpContext.Current.Session.SessionID);
                if (result.Count == 1)
                {
                    return result[0];
                }
            }

        }
        throw new ArgumentException("User is not logged in!");
    }

}